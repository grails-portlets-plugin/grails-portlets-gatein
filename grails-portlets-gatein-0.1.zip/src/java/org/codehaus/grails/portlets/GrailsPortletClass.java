package org.codehaus.grails.portlets;

import org.codehaus.groovy.grails.commons.InjectableGrailsClass;

/**
 * @author Lee Butts
 */
public interface GrailsPortletClass extends InjectableGrailsClass {
}
