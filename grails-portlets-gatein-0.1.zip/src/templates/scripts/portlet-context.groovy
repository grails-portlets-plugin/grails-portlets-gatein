// Use Spring DSL to define the application context specific for portlets
beans = {

}
